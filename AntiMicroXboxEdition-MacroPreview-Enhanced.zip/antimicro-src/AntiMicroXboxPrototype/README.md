# AntiMicro Xbox Edition — UI prototype

This is a UWP/XAML starter project with a classic controller-mapping layout based on the supplied reference screenshot.

## Included
- Xbox Gamepad polling via `Windows.Gaming.Input.Gamepad` while the app is active.
- Live display of buttons, sticks and triggers.
- Keyboard and pointer observation while the app has focus.
- Local JSON profile save/load/delete using `ApplicationData.Current.LocalSettings`.
- Local mapping list, macro-step editor, sequential macro preview, optional repeat mode, stop control, and turbo timing preview.
- Classic two-column mapping panel, stick/sensor/D-pad groups and numbered sets.

## Build
Open `AntiMicroXboxPrototype.sln` in Visual Studio on Windows with the Universal Windows Platform development workload and Windows 10 SDK installed. Select **Release | x64** and build/package the app. The project has not been built or certified in this Linux environment.

## Xbox platform limitation
An ordinary UWP app can read supported gamepad input and observe keyboard/mouse input while it is focused. It cannot act as a system-wide remapper, inject keyboard/mouse events into another Xbox game, create a virtual Xbox controller, or run global macros in the background. Therefore, the included mapping, turbo and macro features are local profile editing and preview functions, not cross-game input emulation.
