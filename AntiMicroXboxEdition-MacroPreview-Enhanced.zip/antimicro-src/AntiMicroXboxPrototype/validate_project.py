from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
root = Path(__file__).parent
checks=[]
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))
for f in ['App.xaml','MainPage.xaml','AntiMicroXboxPrototype.csproj','Package.appxmanifest']:
    try: ET.parse(root/f); check(f'XML parse: {f}', True)
    except Exception as e: check(f'XML parse: {f}', False, str(e))
xaml=(root/'MainPage.xaml').read_text()
cs=(root/'MainPage.xaml.cs').read_text()
handlers=set(re.findall(r'\b(?:Click|Checked|Unchecked|ValueChanged|KeyDown|PointerMoved)="([A-Za-z_][A-Za-z0-9_]*)"', xaml))
methods=set(re.findall(r'\b(?:private|public|protected)\s+(?:static\s+)?(?:void|int|string|ProfileData)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(', cs))
missing=sorted(handlers-methods)
check('XAML event handlers exist', not missing, ', '.join(missing))
for name in ['TurboEnabled_Changed','GetMacroDelay','AdvanceMacroPreview','RefreshController','SaveProfile_Click','LoadProfile_Click']:
    check(f'Expected implementation: {name}', name in methods)
check('Turbo checkbox has stop event', 'Unchecked="TurboEnabled_Changed"' in xaml)
check('Macro preview uses configured delay', 'GetMacroDelay(step)' in cs)
check('Macro preview stop handler exists', 'StopMacro_Click' in methods)
check('Macro repeat mode is wired', 'MacroRepeatEnabled.IsChecked == true' in cs and 'x:Name="MacroRepeatEnabled"' in xaml)
check('Xbox Gamepad API referenced', 'Gamepad.Gamepads' in cs and 'GetCurrentReading()' in cs)
check('No unfinished TODO markers', not re.search(r'\bTODO\b|NotImplementedException', ''.join(p.read_text(errors='ignore') for p in root.rglob('*') if p.is_file() and p.suffix in {'.cs','.xaml','.md'})))
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+'  '+name+((' — '+detail) if detail else ''))
print(f'\n{sum(ok for _,ok,_ in checks)}/{len(checks)} static checks passed')
sys.exit(0 if all(ok for _,ok,_ in checks) else 1)
