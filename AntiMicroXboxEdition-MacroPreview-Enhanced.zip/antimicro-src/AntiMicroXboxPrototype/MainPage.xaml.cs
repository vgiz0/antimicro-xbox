using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using Windows.Gaming.Input;
using Windows.Storage;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;

namespace AntiMicroXboxPrototype
{
    [DataContract]
    public sealed class ProfileData
    {
        [DataMember] public string Name { get; set; }
        [DataMember] public List<string> Mappings { get; set; } = new List<string>();
        [DataMember] public bool TurboEnabled { get; set; }
        [DataMember] public double TurboInterval { get; set; } = 100;
        [DataMember] public List<string> MacroSteps { get; set; } = new List<string>();
    }

    public sealed partial class MainPage : Page
    {
        private readonly DispatcherTimer _pollTimer = new DispatcherTimer();
        private readonly DispatcherTimer _turboTimer = new DispatcherTimer();
        private readonly DispatcherTimer _macroTimer = new DispatcherTimer();
        private readonly ObservableCollection<string> _mappings = new ObservableCollection<string>();
        private readonly ObservableCollection<string> _macroSteps = new ObservableCollection<string>();
        private int _macroIndex;
        private int _turboTicks;

        public MainPage()
        {
            InitializeComponent();
            ButtonsText.Text = "A  —   B  —   X  —   Y  —\nLB —   RB —   View —   Menu —\nD-pad: —";
            AxesText.Text = "Left X: 0.00   Left Y: 0.00\nRight X: 0.00  Right Y: 0.00\nLT: 0.00   RT: 0.00";
            MappingsList.ItemsSource = _mappings;
            MacroStepsList.ItemsSource = _macroSteps;
            ActionCombo.ItemsSource = new List<string> { "Move", "Jump", "Confirm", "Back", "Action 1", "Action 2", "Custom" };
            InputCombo.ItemsSource = new List<string> { "A", "B", "X", "Y", "LB", "RB", "LT", "RT", "D-pad Up", "D-pad Down", "D-pad Left", "D-pad Right", "Left Stick", "Right Stick" };
            MacroActionCombo.ItemsSource = new List<string> { "A", "B", "X", "Y", "LB", "RB", "Wait" };
            ActionCombo.SelectedIndex = 0;
            InputCombo.SelectedIndex = 0;
            MacroActionCombo.SelectedIndex = 0;
            _pollTimer.Interval = TimeSpan.FromMilliseconds(50);
            _pollTimer.Tick += (_, __) => RefreshController();
            _pollTimer.Start();
            _turboTimer.Tick += (_, __) => { _turboTicks++; TurboStatusText.Text = "Preview pulse " + _turboTicks + " (inside app only)"; };
            _macroTimer.Tick += (_, __) => AdvanceMacroPreview();
            Loaded += (_, __) => Focus(FocusState.Programmatic);
        }

        private void RefreshController()
        {
            var pads = Gamepad.Gamepads;
            if (pads.Count == 0)
            {
                StatusText.Text = "Waiting for Xbox controller";
                StatusDot.Fill = new SolidColorBrush(Color.FromArgb(255, 239, 68, 68));
                ButtonsText.Text = "A  —   B  —   X  —   Y  —\nLB —   RB —   View —   Menu —\nD-pad: —";
                AxesText.Text = "Left X: 0.00   Left Y: 0.00\nRight X: 0.00  Right Y: 0.00\nLT: 0.00   RT: 0.00";
                return;
            }

            var r = pads[0].GetCurrentReading();
            var b = r.Buttons;
            StatusText.Text = "Xbox controller connected";
            StatusDot.Fill = new SolidColorBrush(Color.FromArgb(255, 34, 197, 94));
            ButtonsText.Text = "A  " + On(b, GamepadButtons.A) + "   B  " + On(b, GamepadButtons.B) + "   X  " + On(b, GamepadButtons.X) + "   Y  " + On(b, GamepadButtons.Y) +
                "\nLB " + On(b, GamepadButtons.LeftShoulder) + "   RB " + On(b, GamepadButtons.RightShoulder) + "   View " + On(b, GamepadButtons.View) + "   Menu " + On(b, GamepadButtons.Menu) +
                "\nD-pad: " + (On(b, GamepadButtons.DPadUp) == "●" ? "Up " : "") + (On(b, GamepadButtons.DPadDown) == "●" ? "Down " : "") +
                (On(b, GamepadButtons.DPadLeft) == "●" ? "Left " : "") + (On(b, GamepadButtons.DPadRight) == "●" ? "Right" : "—");
            AxesText.Text = "Left X: " + r.LeftThumbstickX.ToString("0.00") + "   Left Y: " + r.LeftThumbstickY.ToString("0.00") +
                "\nRight X: " + r.RightThumbstickX.ToString("0.00") + "  Right Y: " + r.RightThumbstickY.ToString("0.00") +
                "\nLT: " + r.LeftTrigger.ToString("0.00") + "   RT: " + r.RightTrigger.ToString("0.00");
        }

        private static string On(GamepadButtons current, GamepadButtons flag) => (current & flag) == flag ? "●" : "—";

        private void Page_KeyDown(object sender, Windows.UI.Xaml.Input.KeyRoutedEventArgs e)
        {
            KeyboardText.Text = "Last key: " + e.Key.ToString();
        }

        private void Page_PointerMoved(object sender, Windows.UI.Xaml.Input.PointerRoutedEventArgs e)
        {
            var p = e.GetCurrentPoint(this).Position;
            MouseText.Text = "Pointer: X " + ((int)p.X) + "  Y " + ((int)p.Y);
        }

        private void AddMapping_Click(object sender, RoutedEventArgs e)
        {
            if (ActionCombo.SelectedItem == null || InputCombo.SelectedItem == null) return;
            var item = ActionCombo.SelectedItem + "  ←  " + InputCombo.SelectedItem;
            if (!_mappings.Contains(item)) _mappings.Add(item);
            ProfileStatusText.Text = "Mapping added to current profile draft";
        }

        private void AddMacroStep_Click(object sender, RoutedEventArgs e)
        {
            if (MacroActionCombo.SelectedItem == null) return;
            var delay = (int)MacroDelaySlider.Value;
            _macroSteps.Add(MacroActionCombo.SelectedItem + "   ·   " + delay + " ms");
            MacroStatusText.Text = _macroSteps.Count + " step(s) ready for local preview";
        }

        private void ClearMacro_Click(object sender, RoutedEventArgs e)
        {
            _macroTimer.Stop();
            _macroSteps.Clear();
            _macroIndex = 0;
            MacroStatusText.Text = "Macro list cleared";
        }

        private void StopMacro_Click(object sender, RoutedEventArgs e)
        {
            _macroTimer.Stop();
            _macroIndex = 0;
            MacroStatusText.Text = "Preview stopped";
        }

        private void PreviewMacro_Click(object sender, RoutedEventArgs e)
        {
            if (_macroSteps.Count == 0) { MacroStatusText.Text = "Add a step first"; return; }
            _macroTimer.Stop();
            _macroIndex = 0;
            ShowMacroPreviewStep();
            _macroTimer.Start();
        }

        private void ShowMacroPreviewStep()
        {
            if (_macroSteps.Count == 0)
            {
                _macroTimer.Stop();
                MacroStatusText.Text = "No macro steps";
                return;
            }

            var step = _macroSteps[_macroIndex];
            MacroStatusText.Text = "Preview " + (_macroIndex + 1) + "/" + _macroSteps.Count + ": " + step;
            _macroTimer.Interval = TimeSpan.FromMilliseconds(GetMacroDelay(step));
        }

        private void AdvanceMacroPreview()
        {
            _macroIndex++;
            if (_macroIndex >= _macroSteps.Count)
            {
                if (MacroRepeatEnabled.IsChecked == true)
                    _macroIndex = 0;
                else
                {
                    _macroTimer.Stop();
                    MacroStatusText.Text = "Preview complete";
                    return;
                }
            }
            ShowMacroPreviewStep();
        }

        private static int GetMacroDelay(string step)
        {
            var parts = step.Split('·');
            int delay;
            return parts.Length > 1 && int.TryParse(parts[parts.Length - 1].Trim().Replace("ms", "").Trim(), out delay)
                ? Math.Max(50, Math.Min(2000, delay)) : 250;
        }

        protected override void OnNavigatedFrom(Windows.UI.Xaml.Navigation.NavigationEventArgs e)
        {
            _macroTimer.Stop();
            _turboTimer.Stop();
            _pollTimer.Stop();
            base.OnNavigatedFrom(e);
        }

        private void TurboEnabled_Changed(object sender, RoutedEventArgs e)
        {
            if (TurboEnabled == null || TurboStatusText == null) return;
            if (TurboEnabled.IsChecked != true)
            {
                _turboTimer.Stop();
                TurboStatusText.Text = "Stopped";
            }
            else TurboStatusText.Text = "Enabled — preview only";
        }

        private void TurboRateSlider_ValueChanged(object sender, Windows.UI.Xaml.Controls.Primitives.RangeBaseValueChangedEventArgs e)
        {
            if (TurboRateText != null) TurboRateText.Text = "Repeat interval: " + ((int)e.NewValue) + " ms";
            if (_turboTimer != null && _turboTimer.IsEnabled) _turboTimer.Interval = TimeSpan.FromMilliseconds(e.NewValue);
        }

        private void TurboTest_Click(object sender, RoutedEventArgs e)
        {
            _turboTimer.Stop();
            _turboTicks = 0;
            if (TurboEnabled.IsChecked != true)
            {
                TurboStatusText.Text = "Turn on Enable turbo preview first";
                return;
            }
            _turboTimer.Interval = TimeSpan.FromMilliseconds(TurboRateSlider.Value);
            _turboTimer.Start();
            TurboStatusText.Text = "Turbo preview running — uncheck to stop";
        }

        private void SaveProfile_Click(object sender, RoutedEventArgs e)
        {
            var name = (ProfileNameBox.Text ?? "").Trim();
            if (name.Length == 0) { ProfileStatusText.Text = "Enter a profile name"; return; }
            var data = ReadCurrentProfile(name);
            ApplicationData.Current.LocalSettings.Values["profile:" + name] = Serialize(data);
            ProfileStatusText.Text = "Saved locally: " + name;
        }

        private void LoadProfile_Click(object sender, RoutedEventArgs e)
        {
            var name = (ProfileNameBox.Text ?? "").Trim();
            if (name.Length == 0) { ProfileStatusText.Text = "Enter a profile name"; return; }
            var key = "profile:" + name;
            var raw = ApplicationData.Current.LocalSettings.Values[key] as string;
            if (raw == null) { ProfileStatusText.Text = "Profile not found"; return; }
            try
            {
                var data = Deserialize(raw);
                _mappings.Clear(); foreach (var item in data.Mappings) _mappings.Add(item);
                _macroSteps.Clear(); foreach (var item in data.MacroSteps) _macroSteps.Add(item);
                TurboEnabled.IsChecked = data.TurboEnabled;
                TurboRateSlider.Value = Math.Max(TurboRateSlider.Minimum, Math.Min(TurboRateSlider.Maximum, data.TurboInterval));
                ProfileStatusText.Text = "Loaded locally: " + name;
                MacroStatusText.Text = _macroSteps.Count + " step(s) loaded";
            }
            catch (Exception ex) { ProfileStatusText.Text = "Could not read profile: " + ex.Message; }
        }

        private void DeleteProfile_Click(object sender, RoutedEventArgs e)
        {
            var name = (ProfileNameBox.Text ?? "").Trim();
            if (name.Length == 0) { ProfileStatusText.Text = "Enter a profile name"; return; }
            var key = "profile:" + name;
            if (ApplicationData.Current.LocalSettings.Values.ContainsKey(key))
            {
                ApplicationData.Current.LocalSettings.Values.Remove(key);
                ProfileStatusText.Text = "Deleted local profile: " + name;
            }
            else ProfileStatusText.Text = "Profile not found";
        }

        private ProfileData ReadCurrentProfile(string name)
        {
            var p = new ProfileData { Name = name, TurboEnabled = TurboEnabled.IsChecked == true, TurboInterval = TurboRateSlider.Value };
            foreach (var x in _mappings) p.Mappings.Add(x);
            foreach (var x in _macroSteps) p.MacroSteps.Add(x);
            return p;
        }

        private static string Serialize(ProfileData value)
        {
            var serializer = new DataContractJsonSerializer(typeof(ProfileData));
            using (var stream = new MemoryStream())
            {
                serializer.WriteObject(stream, value);
                return System.Text.Encoding.UTF8.GetString(stream.ToArray());
            }
        }

        private static ProfileData Deserialize(string json)
        {
            var serializer = new DataContractJsonSerializer(typeof(ProfileData));
            using (var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(json)))
                return (ProfileData)serializer.ReadObject(stream);
        }
    }
}
